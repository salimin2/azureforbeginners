# Microsoft Azure for Absolute Beginners

Hi! Welcome to the demo files of my course "Microsoft Azure for Absolute Beginners", which you can acces through https://www.azurebarry.com/course/microsoft-azure-for-absolute-beginners

If you want to learn how to use Microsoft Azure and don't know where to start, this course is for you! 

I will take you through what the cloud is, why it is useful, which leads into why Microsoft Azure is such a good platform and how you can use it. We'll go through the Azure services that enable you to get started and build and run your first applications in the cloud. 

And the best thing? You don't need any prior knowledge about cloud computing or Microsoft Azure. 

To follow along, just dowload the source code and follow my instructions in the course. Have fun!

For more courses, check https://www.azurebarry.com/courses
